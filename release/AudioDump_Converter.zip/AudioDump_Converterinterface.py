from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QTableWidgetItem, QHeaderView, QFileDialog, QTabWidget, QMenu, QAbstractItemView, QScrollArea as PyQtScrollArea, QApplication
from PyQt6.QtGui import QAction
import os
import re
import csv
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional

from qfluentwidgets import (
    BodyLabel, CaptionLabel, PushButton, PrimaryPushButton, TitleLabel,
    SimpleCardWidget, HeaderCardWidget, GroupHeaderCardWidget, ScrollArea,
    InfoBarIcon, MessageBox, StateToolTip, Flyout, ImageLabel,
    TableWidget, LineEdit, PillPushButton, setFont, TextEdit, ComboBox
)

from app.common.config import ROOTPATH
from app.common.logging import logger
from app.common.utils import linuxPath2winPath

CURRENT_PLUGIN_DIR = os.path.dirname(__file__)
resource_path = 'app/resource'


def format_millis(ms: float) -> str:
    total_seconds = ms / 1000.0
    minutes = int(total_seconds // 60)
    seconds = total_seconds % 60
    return f"{minutes:02d}:{seconds:06.3f}"


def parse_millis(time_str: str) -> float:
    try:
        parts = time_str.split(':')
        ms = 0
        if len(parts) == 2:
            ms += int(parts[0]) * 60000
            sec_parts = parts[1].split('.')
            ms += int(sec_parts[0]) * 1000
            if len(sec_parts) > 1:
                ms_part = sec_parts[1].ljust(3, '0')[:3]
                ms += int(ms_part)
        return ms
    except:
        return 0.0


def parse_log_time(log_time_str: str, year: int = None) -> datetime:
    if year is None:
        year = datetime.now().year
    try:
        full_str = f"{year}-{log_time_str}"
        return datetime.strptime(full_str, '%Y-%m-%d %H:%M:%S.%f')
    except ValueError:
        return None


class AppInfoCard(SimpleCardWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        logo_path = os.path.join(CURRENT_PLUGIN_DIR, "logo.png")
        if os.path.exists(logo_path):
            self.iconLabel = ImageLabel(logo_path, self)
            self.iconLabel.setBorderRadius(8, 8, 8, 8)
            self.iconLabel.scaledToWidth(120)
        else:
            self.iconLabel = ImageLabel("{}".format(os.path.join(CURRENT_PLUGIN_DIR, "logo.png")), self)
            self.iconLabel.setBorderRadius(8, 8, 8, 8)
            self.iconLabel.scaledToWidth(120)
        self.nameLabel = TitleLabel('通用音频日志时间转换工具', self)
        self.companyLabel = CaptionLabel('@Designed by Charter', self)
        self.descriptionLabel = BodyLabel(
            '本工具用于解析音频日志（frameworks dump、MTK hal dump），建立会话与dump文件的对应关系，支持日志时间与音频文件进度的双向转换。', self)
        self.descriptionLabel.setWordWrap(True)
        self.tagButton = PillPushButton('MTK', self)
        self.tagButton.setCheckable(False)
        setFont(self.tagButton, 12)
        self.tagButton.setFixedSize(60, 32)
        self.tagButton2 = PillPushButton('SPRD', self)
        self.tagButton2.setCheckable(False)
        setFont(self.tagButton2, 12)
        self.tagButton2.setFixedSize(60, 32)
        self.hBoxLayout = QHBoxLayout(self)
        self.vBoxLayout = QVBoxLayout()
        self.topLayout = QHBoxLayout()
        self.buttonLayout = QHBoxLayout()
        self.initLayout()
        self.setBorderRadius(8)

    def initLayout(self):
        self.hBoxLayout.setSpacing(30)
        self.hBoxLayout.setContentsMargins(34, 24, 24, 24)
        self.hBoxLayout.addWidget(self.iconLabel)
        self.hBoxLayout.addLayout(self.vBoxLayout)
        self.vBoxLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.setSpacing(0)
        self.vBoxLayout.addLayout(self.topLayout)
        self.topLayout.setContentsMargins(0, 0, 0, 0)
        self.topLayout.addWidget(self.nameLabel)
        self.vBoxLayout.addSpacing(3)
        self.vBoxLayout.addWidget(self.companyLabel)
        self.vBoxLayout.addSpacing(20)
        self.vBoxLayout.addWidget(self.descriptionLabel)
        self.vBoxLayout.addSpacing(12)
        self.buttonLayout.setContentsMargins(0, 0, 0, 0)
        self.vBoxLayout.addLayout(self.buttonLayout)
        self.buttonLayout.addWidget(self.tagButton, 0, Qt.AlignmentFlag.AlignLeft)
        self.buttonLayout.addWidget(self.tagButton2, 1, Qt.AlignmentFlag.AlignLeft)


class DescriptionCard(HeaderCardWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        desc = (
            "音频日志时间转换工具.\n\n"
            "主要功能:\n"
            "1. 日志类型检测 - 自动识别MTK和SPRD格式\n"
            "2. 会话构建 - 根据开始/暂停/停止事件建立音频会话\n"
            "3. WAV文件匹配 - 扫描目录并匹配转储文件\n"
            "4. 双向时间转换 - 在日志时间与文件进度之间进行转换\n\n"
            "步骤:\n"
            "1. 添加日志文件\n"
            "2.  添加WAV目录\n"
            "3. 点击解析按钮\n"
            "4. 在会话列表中查看结果\n"
            "5. 使用时间转换功能"
        )
        self.descriptionLabel = BodyLabel(desc, self)
        self.descriptionLabel.setWordWrap(True)
        self.viewLayout.addWidget(self.descriptionLabel)
        self.setTitle("Description")
        self.setBorderRadius(8)

class Worker(QThread):
    analysis_complete = pyqtSignal(bool, str)
    progress_update = pyqtSignal(str)
    sessions_ready = pyqtSignal(list)
    wav_matched = pyqtSignal(dict)

    def __init__(self, log_files: list, wav_dirs: list, year: int = None):
        super().__init__()
        self.log_files = log_files
        self.wav_dirs = wav_dirs
        self.year = year if year else datetime.now().year
        self.analyzer = None
        self.wav_files = {}

    def log(self, message):
        self.progress_update.emit(message)
        logger.info(f"[AudioLog Worker] {message}")

    def run(self):
        try:
            self.log("Starting log file parsing...")
            all_lines = []
            for log_file in self.log_files:
                try:
                    with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()
                        all_lines.extend(lines)
                    self.log(f"Read log file: {os.path.basename(log_file)}, {len(lines)} lines")
                except Exception as e:
                    self.log(f"Failed to read: {log_file}, {e}")
            if not all_lines:
                self.analysis_complete.emit(False, "No log content read")
                return
            self.log("Building analyzer...")
            def progress_callback(progress):
                self.progress_update.emit(f"Parse progress: {progress * 100:.1f}%")
            class AudioLogAnalyzer:
                LOG_PATTERN = re.compile(r'^(?:[\w-]+:? *)?(\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})')
                MTK_DUMP_PATTERN = re.compile(r'(?:AudioDumpExt|AudioUtility): new threadDump\(\) (/[^\s]+)_(\d{8}-\d{6})$')
                SPRD_ONFILE_PATTERN = re.compile(r'HypSys-LogMgrFileEventListener: \[OnFileEvent\] fileName: (.+?\.pcm), basePath:')
                SPRD_ALSASTREAMIN_PATTERN = re.compile(r'AudioALSAStreamIn: openWavDump\(\), DumpFileName = (.+?\.wav)[,\s]')
                SPRD_OPENWAVDUMP_PATTERN = re.compile(r'DumpFileName = (/[^\s,]+(?:\.wav|\.pcm))')
                SPRD_SESSIONID_PATTERN = re.compile(r'sessionId_(\d+)_pkg_')

                def __init__(self, lines: List[str], year: int, progress_callback=None):
                    self.lines = lines
                    self.year = year
                    self.progress_callback = progress_callback
                    self.starts: Dict[int, List[datetime]] = {}
                    self.pauses: Dict[int, List[datetime]] = {}
                    self.stops: Dict[int, List[datetime]] = {}
                    self.dumps: List[Tuple[datetime, str, str]] = []
                    self.pcm_files: List[dict] = []
                    self.sessions: List[dict] = []
                    self.log_type = self._detect_log_type()
                    self._parse_log()
                    self._build_sessions()

                def _detect_log_type(self):
                    audio_dump_count = 0
                    file_event_count = 0
                    sample_size = min(350000, len(self.lines))
                    for line in self.lines[:sample_size]:
                        if 'AudioDumpExt: new threadDump()' in line or 'AudioUtility: new threadDump()' in line:
                            audio_dump_count += 1
                        elif 'HypSys-LogMgrFileEventListener' in line and 'OnFileEvent' in line:
                            file_event_count += 1
                    return 'MTK' if audio_dump_count > file_event_count else 'SPRD'

                def _parse_log(self):
                    total = len(self.lines)
                    for idx, line in enumerate(self.lines):
                        if self.progress_callback and idx % 1000 == 0:
                            self.progress_callback(idx / total * 50)
                        m_log = self.LOG_PATTERN.match(line)
                        if not m_log:
                            continue
                        log_time_str = m_log.group(1)
                        full_time_str = f"{self.year}-{log_time_str}"
                        try:
                            log_time = datetime.strptime(full_time_str, '%Y-%m-%d %H:%M:%S.%f')
                        except ValueError:
                            continue
                        if self.log_type == 'MTK':
                            self._parse_mtk_line(line, log_time)
                        else:
                            self._parse_sprd_line(line, log_time)
                    if self.progress_callback:
                        self.progress_callback(50)
                    for port in self.starts:
                        self.starts[port].sort()
                    for port in self.pauses:
                        self.pauses[port].sort()
                    for sid in self.stops:
                        self.stops[sid].sort()
                    self.dumps.sort(key=lambda x: x[0])
                    self.pcm_files.sort(key=lambda x: x['create_time'])

                def _parse_mtk_line(self, line: str, log_time: datetime):
                    start_match = re.search(r'AudioTrack: start\((\d+)\)', line)
                    if start_match:
                        port = int(start_match.group(1))
                        self.starts.setdefault(port, []).append(log_time)
                    pause_match = re.search(r'AudioTrack: pause\((\d+)\)', line)
                    if pause_match:
                        port = int(pause_match.group(1))
                        self.pauses.setdefault(port, []).append(log_time)
                    dump_match = self.MTK_DUMP_PATTERN.search(line)
                    if dump_match:
                        filename = dump_match.group(1).strip()
                        group_ts = dump_match.group(2)
                        self.dumps.append((log_time, filename, group_ts))

                def _parse_sprd_line(self, line: str, log_time: datetime):
                    m_pcm = self.SPRD_ONFILE_PATTERN.search(line)
                    if m_pcm:
                        filename = m_pcm.group(1).strip()
                        m_sessionid = self.SPRD_SESSIONID_PATTERN.search(filename)
                        session_id = int(m_sessionid.group(1)) if m_sessionid else None
                        self.pcm_files.append({'filename': filename, 'create_time': log_time, 'session_id': session_id})
                    m_alsain = self.SPRD_ALSASTREAMIN_PATTERN.search(line)
                    if m_alsain:
                        filename = m_alsain.group(1).strip()
                        self.pcm_files.append({'filename': filename, 'create_time': log_time, 'session_id': None})
                    m_opendump = self.SPRD_OPENWAVDUMP_PATTERN.search(line)
                    if m_opendump and 'AudioALSAStreamIn' not in line:
                        filename = m_opendump.group(1).strip()
                        self.pcm_files.append({'filename': filename, 'create_time': log_time, 'session_id': None})
                    start_match = re.search(r'AudioTrack: start\((\d+)\): prior state:STATE_STOPPED', line)
                    if start_match:
                        port = int(start_match.group(1))
                        self.starts.setdefault(port, []).append(log_time)
                    pause_match = re.search(r'AudioTrack: pause\(sessionID=(\d+)\) pause\((\d+)\)', line)
                    if pause_match:
                        port = int(pause_match.group(2))
                        self.pauses.setdefault(port, []).append(log_time)
                    stop_match = re.search(r'AudioTrack: stop\(sessionID=(\d+)\)', line)
                    if stop_match:
                        session_id = int(stop_match.group(1))
                        self.stops.setdefault(session_id, []).append(log_time)
                    else:
                        stop_match = re.search(r'AudioTrack: stop\((\d+)\)', line)
                        if stop_match:
                            port = int(stop_match.group(1))
                            self.stops.setdefault(port, []).append(log_time)

                def _build_intervals_for_port(self, port: int) -> List[Tuple[datetime, Optional[datetime]]]:
                    starts = self.starts.get(port, [])
                    pauses = self.pauses.get(port, [])
                    if not starts:
                        return []
                    intervals = []
                    i, j = 0, 0
                    while i < len(starts):
                        s = starts[i]
                        while j < len(pauses) and pauses[j] <= s:
                            j += 1
                        e = pauses[j] if j < len(pauses) else None
                        intervals.append((s, e))
                        if e is not None:
                            j += 1
                        i += 1
                    return intervals

                def _build_sessions(self):
                    if self.log_type == 'MTK':
                        self._build_mtk_sessions()
                    else:
                        self._build_sprd_sessions()
                    self.sessions.sort(key=lambda s: s['start_time'])

                def _build_mtk_sessions(self):
                    groups: Dict[str, List[Tuple[datetime, str]]] = {}
                    for dt, fname, ts in self.dumps:
                        groups.setdefault(ts, []).append((dt, fname))
                    for group_ts, file_list in groups.items():
                        port = None
                        for dt, fname in file_list:
                            if 'af_track' in fname:
                                m = re.search(r'port(\d+)', fname)
                                if m:
                                    port = int(m.group(1))
                                    break
                        if port is None:
                            continue
                        intervals = self._build_intervals_for_port(port)
                        if not intervals:
                            continue
                        min_dump = min(dt for dt, _ in file_list)
                        matched_interval = None
                        for s, e in intervals:
                            if s <= min_dump and (e is None or min_dump <= e):
                                matched_interval = (s, e)
                                break
                        if matched_interval is None:
                            cand_starts = [s for s, _ in intervals if s <= min_dump]
                            if cand_starts:
                                latest_start = max(cand_starts)
                                pause_before = None
                                for s, e in intervals:
                                    if s == latest_start:
                                        pause_before = e
                                        break
                                if pause_before is None or pause_before > min_dump:
                                    matched_interval = (latest_start, pause_before)
                        if matched_interval:
                            start_time, end_time = matched_interval
                            session = {
                                'port': port,
                                'start_time': start_time,
                                'end_time': end_time,
                                'group_timestamp': group_ts,
                                'files': [{'filename': fn, 'dump_time': dt} for dt, fn in file_list]
                            }
                            self.sessions.append(session)

                def _build_sprd_sessions(self):
                    seen = set()
                    unique_pcm_files = []
                    for pcm in self.pcm_files:
                        key = (pcm['session_id'], pcm['filename'])
                        if key not in seen:
                            seen.add(key)
                            unique_pcm_files.append(pcm)
                    for pcm in unique_pcm_files:
                        session_id = pcm['session_id']
                        create_time = pcm['create_time']
                        start_time = None
                        end_time = None
                        port = None
                        for p, starts_list in self.starts.items():
                            for st in starts_list:
                                if st <= create_time:
                                    if start_time is None or st > start_time:
                                        start_time = st
                                        port = p
                        if session_id is not None and session_id in self.stops:
                            stop_list = self.stops[session_id]
                            for st in stop_list:
                                if st >= create_time:
                                    end_time = st
                                    break
                            if end_time is None and stop_list:
                                end_time = stop_list[-1]
                        if (end_time is None or end_time < create_time) and port is not None and port in self.stops:
                            stop_list = self.stops[port]
                            end_time = None
                            for st in stop_list:
                                if st >= create_time:
                                    end_time = st
                                    break
                            if end_time is None and create_time > (stop_list[-1] if stop_list else create_time):
                                end_time = None
                        if start_time is None:
                            start_time = create_time
                        session = {
                            'session_id': session_id,
                            'port': port,
                            'start_time': start_time,
                            'end_time': end_time,
                            'pcm_file': pcm
                        }
                        self.sessions.append(session)

                def get_sessions(self):
                    return self.sessions

                def query_by_log_time(self, log_time: datetime) -> List[dict]:
                    results = []
                    for sess in self.sessions:
                        start = sess['start_time']
                        end = sess['end_time']
                        if start <= log_time and (end is None or log_time <= end):
                            session_progress_ms = (log_time - start).total_seconds() * 1000
                            if self.log_type == 'MTK':
                                file_progress = []
                                for f in sess['files']:
                                    dump_time = f['dump_time']
                                    if log_time < dump_time:
                                        file_offset_ms = 0.0
                                    else:
                                        file_offset_ms = (log_time - dump_time).total_seconds() * 1000
                                    file_progress.append({'filename': f['filename'], 'dump_time': dump_time, 'offset_ms': file_offset_ms})
                                results.append({
                                    'port': sess['port'],
                                    'start_time': start,
                                    'end_time': end,
                                    'session_progress_ms': session_progress_ms,
                                    'file_progress': file_progress,
                                    'group_timestamp': sess['group_timestamp']
                                })
                            else:
                                pcm = sess['pcm_file']
                                create_time = pcm['create_time']
                                offset_ms = 0.0 if log_time < create_time else (log_time - create_time).total_seconds() * 1000
                                results.append({
                                    'session_id': sess['session_id'],
                                    'port': sess['port'],
                                    'start_time': start,
                                    'end_time': end,
                                    'session_progress_ms': session_progress_ms,
                                    'pcm_filename': pcm['filename'],
                                    'pcm_create_time': create_time,
                                    'offset_ms': offset_ms
                                })
                    return results

                def progress_to_log_time(self, session_index: int, file_index: int, progress_ms: float) -> Optional[datetime]:
                    if session_index < 0 or session_index >= len(self.sessions):
                        return None
                    sess = self.sessions[session_index]
                    if self.log_type == 'MTK':
                        if file_index < 0 or file_index >= len(sess['files']):
                            return None
                        dump_time = sess['files'][file_index]['dump_time']
                        return dump_time + timedelta(milliseconds=progress_ms)
                    else:
                        pcm = sess['pcm_file']
                        create_time = pcm['create_time']
                        return create_time + timedelta(milliseconds=progress_ms)

                def scan_wav_dir(self, directories: List[str]) -> Dict[str, str]:
                    wav_files: Dict[str, str] = {}
                    earliest_time = None
                    for directory in directories:
                        if not os.path.isdir(directory):
                            continue
                        for root, dirs, files in os.walk(directory):
                            for file in files:
                                if file.lower().endswith('.wav'):
                                    filepath = os.path.join(root, file)
                                    base = os.path.splitext(file)[0]
                                    wav_files[base] = filepath
                                    try:
                                        mtime = os.path.getmtime(filepath)
                                        if earliest_time is None or mtime < earliest_time:
                                            earliest_time = mtime
                                    except:
                                        pass
                    return wav_files, earliest_time

                def get_sessions(self):
                    return self.sessions

                def query_by_log_time(self, log_time: datetime) -> List[dict]:
                    results = []
                    for sess in self.sessions:
                        start = sess['start_time']
                        end = sess['end_time']
                        if start <= log_time and (end is None or log_time <= end):
                            session_progress_ms = (log_time - start).total_seconds() * 1000
                            if self.log_type == 'MTK':
                                file_progress = []
                                for f in sess['files']:
                                    dump_time = f['dump_time']
                                    if log_time < dump_time:
                                        file_offset_ms = 0.0
                                    else:
                                        file_offset_ms = (log_time - dump_time).total_seconds() * 1000
                                    file_progress.append({'filename': f['filename'], 'dump_time': dump_time, 'offset_ms': file_offset_ms})
                                results.append({
                                    'port': sess['port'],
                                    'start_time': start,
                                    'end_time': end,
                                    'session_progress_ms': session_progress_ms,
                                    'file_progress': file_progress,
                                    'group_timestamp': sess['group_timestamp']
                                })
                            else:
                                pcm = sess['pcm_file']
                                create_time = pcm['create_time']
                                offset_ms = 0.0 if log_time < create_time else (log_time - create_time).total_seconds() * 1000
                                results.append({
                                    'session_id': sess['session_id'],
                                    'port': sess['port'],
                                    'start_time': start,
                                    'end_time': end,
                                    'session_progress_ms': session_progress_ms,
                                    'pcm_filename': pcm['filename'],
                                    'pcm_create_time': create_time,
                                    'offset_ms': offset_ms
                                })
                    return results

                def progress_to_log_time(self, session_index: int, file_index: int, progress_ms: float) -> Optional[datetime]:
                    if session_index < 0 or session_index >= len(self.sessions):
                        return None
                    sess = self.sessions[session_index]
                    if self.log_type == 'MTK':
                        if file_index < 0 or file_index >= len(sess['files']):
                            return None
                        dump_time = sess['files'][file_index]['dump_time']
                        return dump_time + timedelta(milliseconds=progress_ms)
                    else:
                        pcm = sess['pcm_file']
                        create_time = pcm['create_time']
                        return create_time + timedelta(milliseconds=progress_ms)

                def scan_wav_dir(self, directories: List[str]) -> Dict[str, str]:
                    wav_files: Dict[str, str] = {}
                    earliest_time = None
                    for directory in directories:
                        if not os.path.isdir(directory):
                            continue
                        for root, dirs, files in os.walk(directory):
                            for file in files:
                                if file.lower().endswith('.wav'):
                                    filepath = os.path.join(root, file)
                                    base = os.path.splitext(file)[0]
                                    wav_files[base] = filepath
                                    try:
                                        mtime = os.path.getmtime(filepath)
                                        if earliest_time is None or mtime < earliest_time:
                                            earliest_time = mtime
                                    except:
                                        pass
                    return wav_files, earliest_time
            self.analyzer = AudioLogAnalyzer(all_lines, self.year, progress_callback)
            self.log(f"Log type: {self.analyzer.log_type}")
            self.log(f"Found {len(self.analyzer.sessions)} sessions")
            if self.wav_dirs:
                self.log("Scanning WAV directories...")
                self.wav_files, earliest_time = self.analyzer.scan_wav_dir(self.wav_dirs)
                self.log(f"Found {len(self.wav_files)} WAV files")
                self.wav_matched.emit(self.wav_files)
                if earliest_time and self.year is None:
                    from datetime import datetime as dt
                    self.year = dt.fromtimestamp(earliest_time).year
            sessions_data = []
            for idx, sess in enumerate(self.analyzer.sessions):
                if self.analyzer.log_type == 'MTK':
                    start_str = sess['start_time'].strftime('%m-%d %H:%M:%S.%f')[:-3] if sess['start_time'] else 'N/A'
                    end_str = sess['end_time'].strftime('%m-%d %H:%M:%S.%f')[:-3] if sess['end_time'] else 'N/A'
                    duration_ms = 0
                    if sess['end_time'] and sess['start_time']:
                        duration_ms = (sess['end_time'] - sess['start_time']).total_seconds() * 1000
                    elif sess['start_time']:
                        duration_ms = (datetime.now() - sess['start_time']).total_seconds() * 1000
                    files_info = []
                    for f in sess['files']:
                        dump_str = f['dump_time'].strftime('%m-%d %H:%M:%S.%f')[:-3] if f['dump_time'] else 'N/A'
                        basename = os.path.basename(f['filename'])
                        wav_key = basename + '_' + sess.get('group_timestamp', '')
                        wav_match = 'Y' if wav_key in self.wav_files else 'N'
                        files_info.append({'filename': basename, 'dump_time': dump_str, 'full_path': f['filename'], 'wav_key': wav_key})
                    sessions_data.append({'index': idx, 'port': sess.get('port'), 'start_time': start_str, 'end_time': end_str, 'duration': format_millis(duration_ms), 'log_type': 'MTK', 'files': files_info, 'group_timestamp': sess.get('group_timestamp', '')})
                else:
                    start_str = sess['start_time'].strftime('%m-%d %H:%M:%S.%f')[:-3] if sess['start_time'] else 'N/A'
                    end_str = sess['end_time'].strftime('%m-%d %H:%M:%S.%f')[:-3] if sess['end_time'] else 'N/A'
                    duration_ms = 0
                    if sess['end_time'] and sess['start_time']:
                        duration_ms = (sess['end_time'] - sess['start_time']).total_seconds() * 1000
                    elif sess['start_time']:
                        duration_ms = (datetime.now() - sess['start_time']).total_seconds() * 1000
                    pcm = sess.get('pcm_file', {})
                    pcm_filename = os.path.basename(pcm.get('filename', '')) if pcm else 'N/A'
                    pcm_wav_key = os.path.splitext(pcm_filename)[0]
                    create_str = pcm.get('create_time', datetime.now()).strftime('%m-%d %H:%M:%S.%f')[:-3] if pcm.get('create_time') else 'N/A'
                    wav_match = 'Y' if pcm_wav_key in self.wav_files else 'N'
                    sessions_data.append({'index': idx, 'port': sess.get('port'), 'session_id': sess.get('session_id'), 'start_time': start_str, 'end_time': end_str, 'duration': format_millis(duration_ms), 'log_type': 'SPRD', 'pcm_file': pcm_filename, 'create_time': create_str, 'full_path': pcm.get('filename', '')})
            self.sessions_ready.emit(sessions_data)
            summary = f"=== Analysis Complete ===\\n\\nLog type: {self.analyzer.log_type}\\nSessions: {len(self.analyzer.sessions)}\\nWAV files: {len(self.wav_files)}\\n"
            self.analysis_complete.emit(True, summary)
        except Exception as e:
            logger.error(f"Analysis failed: {e}")
            self.analysis_complete.emit(False, f"Analysis failed: {str(e)}")

class SettingsCard(GroupHeaderCardWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Audio Log Analysis Settings")
        self.setBorderRadius(8)
        self.log_files: List[str] = []
        self.wav_dirs: List[str] = []
        self.worker = None
        self.stateTooltip = None
        self.main_window = None
        self.init_ui()

    def init_ui(self):
        self.addLogButton = PushButton("添加")
        self.addLogButton.setFixedWidth(120)
        self.logFilesLabel = BodyLabel("未选择", self)
        self.logFilesLabel.setWordWrap(True)
        clearLogBtn = PushButton("清除")
        clearLogBtn.setFixedWidth(80)
        clearLogBtn.clicked.connect(self.onClearLogClicked)
        self.addWavButton = PushButton("添加目录")
        self.addWavButton.setFixedWidth(120)
        self.wavDirsLabel = BodyLabel("未选择", self)
        self.wavDirsLabel.setWordWrap(True)
        clearWavBtn = PushButton("清除")
        clearWavBtn.setFixedWidth(80)
        clearWavBtn.clicked.connect(self.onClearWavClicked)
        log_widget = QWidget()
        log_layout = QHBoxLayout(log_widget)
        log_layout.setContentsMargins(0, 0, 0, 0)
        log_layout.addWidget(self.addLogButton)
        log_layout.addSpacing(10)
        log_layout.addWidget(clearLogBtn)
        log_layout.addSpacing(10)
        log_layout.addWidget(self.logFilesLabel, 1)
        wav_widget = QWidget()
        wav_layout = QHBoxLayout(wav_widget)
        wav_layout.setContentsMargins(0, 0, 0, 0)
        wav_layout.addWidget(self.addWavButton)
        wav_layout.addSpacing(10)
        wav_layout.addWidget(clearWavBtn)
        wav_layout.addSpacing(10)
        wav_layout.addWidget(self.wavDirsLabel, 1)
        self.addGroup("{}/images/Rocket.svg".format(resource_path), "AP Log", "Select log/txt files", log_widget)
        self.addGroup("{}/images/Rocket.svg".format(resource_path), "音频文件目录", "Select WAV dump directory", wav_widget)
        self.parseButton = PrimaryPushButton("解析")
        self.parseButton.setFixedWidth(150)
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)
        button_layout.addWidget(self.parseButton)
        button_layout.addStretch(1)
        self.vBoxLayout.addLayout(button_layout)
        self.vBoxLayout.addSpacing(20)
        self.addLogButton.clicked.connect(self.onAddLogClicked)
        self.addWavButton.clicked.connect(self.onAddWavClicked)
        self.parseButton.clicked.connect(self.onParseClicked)

    def set_main_window(self, main_window):
        self.main_window = main_window

    def onAddLogClicked(self):
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
        files, _ = QFileDialog.getOpenFileNames(self, "Select Log Files", "", "All files (*.*)")
        if files:
            for file in files:
                file = linuxPath2winPath(file)
                if file not in self.log_files:
                    self.log_files.append(file)
            self.logFilesLabel.setText(f"Selected {len(self.log_files)} files")
            logger.info(f"Added log files: {files}")

    def onClearLogClicked(self):
        self.log_files = []
        self.logFilesLabel.setText("Not selected")
        logger.info("Cleared log files")

    def onAddWavClicked(self):
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
        directory = QFileDialog.getExistingDirectory(self.window(), "Select WAV Directory", "")
        if directory:
            directory = linuxPath2winPath(directory)
            if directory not in self.wav_dirs:
                self.wav_dirs.append(directory)
            self.wavDirsLabel.setText(f"Selected {len(self.wav_dirs)} directories")
            logger.info(f"Added WAV directory: {directory}")

    def onClearWavClicked(self):
        self.wav_dirs = []
        self.wavDirsLabel.setText("Not selected")
        logger.info("Cleared WAV directories")

    def showErrorFlyout(self, title, content):
        Flyout.create(icon=InfoBarIcon.ERROR, title=title, content=content, target=self.parseButton, parent=self.window())

    def onParseClicked(self):
        if not self.log_files:
            self.showErrorFlyout("Error", "Please select at least one log file")
            return
        if self.stateTooltip:
            try:
                self.stateTooltip.close()
            except:
                pass
            self.stateTooltip = None
        try:
            self.stateTooltip = StateToolTip('Parsing logs', 'Please wait...', self)
            self.stateTooltip.show()
        except Exception as e:
            logger.error(f"Failed to create tooltip: {e}")
            self.stateTooltip = None
        self.parseButton.setDisabled(True)
        try:
            self.worker = Worker(self.log_files, self.wav_dirs)
            self.worker.analysis_complete.connect(self.onAnalysisComplete)
            self.worker.progress_update.connect(self.onProgressUpdate)
            if self.main_window and hasattr(self.main_window, 'updateSessionsTable'):
                self.worker.sessions_ready.connect(self.main_window.updateSessionsTable)
                self.worker.wav_matched.connect(self.main_window.onWavMatched)
                self.worker.analysis_complete.connect(lambda success, msg: self.onWorkerComplete(success, msg, self.worker))
            else:
                parent = self.parent()
                while parent and not hasattr(parent, 'updateSessionsTable'):
                    parent = parent.parent()
                if parent and hasattr(parent, 'updateSessionsTable'):
                    self.worker.sessions_ready.connect(parent.updateSessionsTable)
                    self.worker.wav_matched.connect(parent.onWavMatched)
                    self.worker.analysis_complete.connect(lambda success, msg: self.onWorkerComplete(success, msg, self.worker))
            self.worker.start()
        except Exception as e:
            logger.error(f"Failed to start worker: {e}")
            self.parseButton.setEnabled(True)
            if self.stateTooltip:
                self.stateTooltip.close()
                self.stateTooltip = None
            MessageBox("Error", "Failed to start analysis:\\n" + str(e), self.window()).exec()

    def onWorkerComplete(self, success, message, worker):
        if success and self.main_window and hasattr(self.main_window, 'set_worker_data'):
            self.main_window.set_worker_data(worker)
        elif success:
            parent = self.parent()
            while parent and not hasattr(parent, 'set_worker_data'):
                parent = parent.parent()
            if parent and hasattr(parent, 'set_worker_data'):
                parent.set_worker_data(worker)

    def onProgressUpdate(self, message):
        logger.info(f"[Progress] {message}")

    def onAnalysisComplete(self, success, message):
        self.parseButton.setEnabled(True)
        if self.stateTooltip:
            self.stateTooltip.close()
            self.stateTooltip = None
        if success:
            MessageBox("Complete", message, self.window()).exec()
        else:
            MessageBox("Failed", message, self.window()).exec()



class AnalysisTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_widget = parent
        self.worker_instance = None
        self.sessions_data = []
        self.wav_files = {}
        self.tab_widget = QTabWidget()
        self.session_tab = self.createSessionTab()
        self.query_logtime_tab = self.createQueryLogTimeTab()
        self.query_progress_tab = self.createQueryProgressTab()
        self.tab_widget.addTab(self.session_tab, "Session List")
        self.tab_widget.addTab(self.query_logtime_tab, "Log Time -> Progress")
        self.tab_widget.addTab(self.query_progress_tab, "Progress -> Log Time")
        layout = QVBoxLayout(self)
        layout.addWidget(self.tab_widget)

    def export_table_to_csv(self, table_widget, default_name="export.csv"):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export CSV", default_name, "CSV files (*.csv)")
        if not file_path:
            return
        visible_columns = []
        for col in range(table_widget.columnCount()):
            if not table_widget.isColumnHidden(col):
                visible_columns.append(col)
        headers = []
        for col in visible_columns:
            header_item = table_widget.horizontalHeaderItem(col)
            headers.append(header_item.text() if header_item else "Column" + str(col))
        rows = []
        for row in range(table_widget.rowCount()):
            row_data = []
            for col in visible_columns:
                item = table_widget.item(row, col)
                row_data.append(item.text() if item else "")
            rows.append(row_data)
        try:
            with open(file_path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(headers)
                writer.writerows(rows)
            MessageBox("Success", "Exported " + str(len(rows)) + " rows to:\\n" + file_path, self).exec()
        except Exception as e:
            MessageBox("Error", "Export failed: " + str(e), self).exec()

    def createSessionTab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.session_table = TableWidget()
        self.session_table.setColumnCount(6)
        self.session_table.setHorizontalHeaderLabels(["Index", "Type", "Port", "Start Time", "End Time", "Duration"])
        self.session_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.session_table.setAlternatingRowColors(True)
        self.session_table.setBorderVisible(True)
        self.session_table.setBorderRadius(8)
        self.session_table.setMinimumHeight(400)
        self.session_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.session_table.customContextMenuRequested.connect(lambda pos, table=self.session_table: self.showTableContextMenu(pos, table))
        self.session_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.session_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        layout.addWidget(self.session_table)
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.export_session_btn = PushButton("Export CSV")
        self.export_session_btn.clicked.connect(lambda: self.export_table_to_csv(self.session_table, "sessions.csv"))
        btn_layout.addWidget(self.export_session_btn)
        layout.addLayout(btn_layout)
        return widget

    def showTableContextMenu(self, pos, table):
        menu = QMenu(table)
        menu.setStyleSheet("QMenu { background-color: #ffffff; }")
        copy_cell_action = QAction("复制单元", table)
        copy_cell_action.triggered.connect(lambda: self.copyTableCell(table, pos))
        copy_row_action = QAction("复制行", table)
        copy_row_action.triggered.connect(lambda: self.copyTableRow(table, pos))
        menu.addAction(copy_cell_action)
        menu.addAction(copy_row_action)
        if table == self.logtime_result_table:
            open_dir_action = QAction("打开文件路径", table)
            open_dir_action.triggered.connect(lambda: self.openLogtimeFileDirectory(table.rowAt(pos.y())))
            menu.addAction(open_dir_action)
        menu.exec(table.viewport().mapToGlobal(pos))

    def copyTableCell(self, table, pos):
        row = table.rowAt(pos.y())
        col = table.columnAt(pos.x())
        if row >= 0 and col >= 0:
            item = table.item(row, col)
            if item:
                clipboard = QApplication.clipboard()
                clipboard.setText(item.text())

    def copyTableRow(self, table, pos):
        row = table.rowAt(pos.y())
        if row >= 0:
            items = []
            for col in range(table.columnCount()):
                item = table.item(row, col)
                items.append(item.text() if item else "")
            clipboard = QApplication.clipboard()
            clipboard.setText("\t".join(items))

    def openLogtimeFileDirectory(self, row):
        if row < 0:
            return
        filename_item = self.logtime_result_table.item(row, 3)
        if not filename_item:
            return
        filename = filename_item.text()
        wav_key = os.path.splitext(filename)[0]
        logger.info(f"[AudioLog] openLogtimeFileDirectory: filename={filename}, wav_key={wav_key}, wav_files_count={len(self.wav_files)}, wav_key_in_files={wav_key in self.wav_files}")
        import subprocess
        if wav_key in self.wav_files:
            filepath = self.wav_files[wav_key]
            subprocess.run(["explorer", "/select,", filepath], shell=True)
        else:
            for k, v in self.wav_files.items():
                if wav_key in k or k in wav_key:
                    logger.info(f"[AudioLog] Partial match found: {k}")
                    subprocess.run(["explorer", "/select,", v], shell=True)
                    return

    def showSessionContextMenu(self, position):
        row = self.session_table.rowAt(position.y())
        if row < 0:
            return
        menu = QMenu()
        open_action = QAction("Open File Directory", self)
        open_action.triggered.connect(lambda: self.openSessionDirectory(row))
        menu.addAction(open_action)
        menu.exec(self.session_table.viewport().mapToGlobal(position))

    def openSessionDirectory(self, row):
        if row < len(self.sessions_data):
            sess = self.sessions_data[row]
            full_path = sess.get("full_path", "")
            if full_path and os.path.exists(full_path):
                import subprocess
                subprocess.run(["explorer", "/select,", full_path], shell=True)

    def createQueryLogTimeTab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        query_group = GroupHeaderCardWidget()
        query_group.setTitle("Log Time to File Progress")
        input_layout = QHBoxLayout()
        input_layout.addWidget(BodyLabel("Log Time (MM-DD HH:MM:SS.mmm):"))
        self.logtime_input = LineEdit()
        self.logtime_input.setPlaceholderText("01-15 10:30:45.123")
        input_layout.addWidget(self.logtime_input, 1)
        self.query_logtime_btn = PrimaryPushButton("查询")
        input_layout.addWidget(self.query_logtime_btn)
        query_group.viewLayout.addLayout(input_layout)
        self.logtime_result_table = TableWidget()
        self.logtime_result_table.setColumnCount(6)
        self.logtime_result_table.setHorizontalHeaderLabels(["Session Index", "Type", "Session Progress", "Filename", "Dump Time", "File Offset"])
        self.logtime_result_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.logtime_result_table.setAlternatingRowColors(True)
        self.logtime_result_table.setBorderVisible(True)
        self.logtime_result_table.setBorderRadius(8)
        self.logtime_result_table.setMinimumHeight(300)
        self.logtime_result_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.logtime_result_table.customContextMenuRequested.connect(lambda pos, table=self.logtime_result_table: self.showTableContextMenu(pos, table))
        self.logtime_result_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.logtime_summary = TextEdit()
        self.logtime_summary.setReadOnly(True)
        self.logtime_summary.setMaximumHeight(150)
        layout.addWidget(query_group)
        layout.addSpacing(10)
        layout.addWidget(self.logtime_result_table)
        layout.addSpacing(10)
        layout.addWidget(self.logtime_summary)
        self.query_logtime_btn.clicked.connect(self.onQueryLogTime)
        return widget

    def onQueryLogTime(self):
        if not self.worker_instance or not self.worker_instance.analyzer:
            self.logtime_summary.setText("Error: Please load and analyze data first")
            return
        time_str = self.logtime_input.text()
        if not time_str:
            self.logtime_summary.setText("Error: Please input log time")
            return
        log_time = parse_log_time(time_str)
        if not log_time:
            self.logtime_summary.setText("Error: Cannot parse time string: " + time_str)
            return
        analyzer = self.worker_instance.analyzer
        results = analyzer.query_by_log_time(log_time)
        self.logtime_result_table.setRowCount(0)
        summary_lines = ["Query time: " + time_str, "Found " + str(len(results)) + " matching sessions:"]
        for res in results:
            if analyzer.log_type == "MTK":
                group_ts = res.get("group_timestamp", "")
                for fp in res.get("file_progress", []):
                    row_pos = self.logtime_result_table.rowCount()
                    self.logtime_result_table.insertRow(row_pos)
                    self.logtime_result_table.setItem(row_pos, 0, QTableWidgetItem(str(res.get("index", ""))))
                    self.logtime_result_table.setItem(row_pos, 1, QTableWidgetItem("MTK"))
                    self.logtime_result_table.setItem(row_pos, 2, QTableWidgetItem(format_millis(res.get("session_progress_ms", 0))))
                    base_name = os.path.basename(fp.get("filename", ""))
                    full_filename = base_name + '_' + group_ts
                    self.logtime_result_table.setItem(row_pos, 3, QTableWidgetItem(full_filename))
                    dump_t = fp.get("dump_time", "")
                    dump_str = dump_t.strftime("%m-%d %H:%M:%S.%f")[:-3] if hasattr(dump_t, "strftime") else str(dump_t)
                    self.logtime_result_table.setItem(row_pos, 4, QTableWidgetItem(dump_str))
                    self.logtime_result_table.setItem(row_pos, 5, QTableWidgetItem(format_millis(fp.get("offset_ms", 0))))
            else:
                row_pos = self.logtime_result_table.rowCount()
                self.logtime_result_table.insertRow(row_pos)
                self.logtime_result_table.setItem(row_pos, 0, QTableWidgetItem(str(res.get("index", ""))))
                self.logtime_result_table.setItem(row_pos, 1, QTableWidgetItem("SPRD"))
                self.logtime_result_table.setItem(row_pos, 2, QTableWidgetItem(format_millis(res.get("session_progress_ms", 0))))
                self.logtime_result_table.setItem(row_pos, 3, QTableWidgetItem(res.get("pcm_filename", "")))
                create_t = res.get("pcm_create_time", "")
                create_str = create_t.strftime("%m-%d %H:%M:%S.%f")[:-3] if hasattr(create_t, "strftime") else str(create_t)
                self.logtime_result_table.setItem(row_pos, 4, QTableWidgetItem(create_str))
                self.logtime_result_table.setItem(row_pos, 5, QTableWidgetItem(format_millis(res.get("offset_ms", 0))))
        self.logtime_summary.setText("\\n".join(summary_lines))

    def createQueryProgressTab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        query_group = GroupHeaderCardWidget()
        query_group.setTitle("File Progress to Log Time")
        input_layout = QVBoxLayout()

        input_layout.addWidget(BodyLabel("Select Session:"))
        self.progress_session_combo = ComboBox()
        self.progress_session_combo.setMinimumWidth(300)
        input_layout.addWidget(self.progress_session_combo)

        input_layout.addWidget(BodyLabel("Select File:"))
        self.progress_file_combo = ComboBox()
        self.progress_file_combo.setMinimumWidth(300)
        input_layout.addWidget(self.progress_file_combo)

        row2 = QHBoxLayout()
        row2.addWidget(BodyLabel("File Progress (MM:SS.sss):"))
        self.progress_input = LineEdit()
        self.progress_input.setPlaceholderText("01:30.456")
        row2.addWidget(self.progress_input, 1)
        self.query_progress_btn = PrimaryPushButton("查询")
        row2.addWidget(self.query_progress_btn)
        input_layout.addLayout(row2)
        query_group.viewLayout.addLayout(input_layout)
        self.progress_result = TextEdit()
        self.progress_result.setReadOnly(True)
        self.progress_result.setMaximumHeight(200)
        layout.addWidget(query_group)
        layout.addSpacing(10)
        layout.addWidget(self.progress_result)
        self.query_progress_btn.clicked.connect(self.onQueryProgress)
        self.progress_session_combo.currentIndexChanged.connect(self.onProgressSessionChanged)
        return widget

    def onProgressSessionChanged(self):
        if not self.sessions_data:
            return
        idx = self.progress_session_combo.currentIndex()
        if idx < 0:
            return
        if idx >= len(self.sessions_data):
            return
        sess = self.sessions_data[idx]
        file_choices = []
        log_type = sess.get("log_type", "")
        if log_type == "MTK":
            group_ts = sess.get("group_timestamp", "")
            for i, f in enumerate(sess.get("files", [])):
                base_name = os.path.basename(f.get("filename", ""))
                full_base = base_name + group_ts
                file_choices.append(f"{i}: {full_base}")
        else:
            pcm = sess.get("pcm_file", {})
            base_name = os.path.basename(pcm.get("filename", ""))
            file_choices.append(f"0: {base_name}")
        self.progress_file_combo.clear()
        self.progress_file_combo.addItems(file_choices)

    def onQueryProgress(self):
        if not self.worker_instance or not self.worker_instance.analyzer:
            self.progress_result.setText("Error: Please load and analyze data first")
            return
        try:
            session_idx = self.progress_session_combo.currentIndex()
            file_idx = self.progress_file_combo.currentIndex()
            progress_str = self.progress_input.text()
            if not progress_str:
                self.progress_result.setText("Error: Please input file progress")
                return
            progress_ms = parse_millis(progress_str)
            analyzer = self.worker_instance.analyzer
            result_time = analyzer.progress_to_log_time(session_idx, file_idx, progress_ms)
            if result_time:
                result_str = result_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                self.progress_result.setText("Corresponding log time: " + result_str)
            else:
                self.progress_result.setText("Error: Cannot convert, check session and file indices")
        except ValueError as e:
            self.progress_result.setText("Error: Invalid input format - " + str(e))

    def updateSessionsTable(self, sessions_data):
        self.sessions_data = sessions_data
        self.session_table.setRowCount(len(sessions_data))
        for row, sess in enumerate(sessions_data):
            self.session_table.setItem(row, 0, QTableWidgetItem(str(sess.get("index", ""))))
            self.session_table.setItem(row, 1, QTableWidgetItem(sess.get("log_type", "")))
            port = sess.get("port", "")
            session_id = sess.get("session_id", "")
            id_str = str(port) if port else (str(session_id) if session_id else "N/A")
            self.session_table.setItem(row, 2, QTableWidgetItem(id_str))
            self.session_table.setItem(row, 3, QTableWidgetItem(sess.get("start_time", "")))
            self.session_table.setItem(row, 4, QTableWidgetItem(sess.get("end_time", "")))
            self.session_table.setItem(row, 5, QTableWidgetItem(sess.get("duration", "")))
        self.updateProgressCombo()

    def updateProgressCombo(self):
        combo_values = []
        for idx, sess in enumerate(self.sessions_data):
            start_str = sess.get("start_time", "N/A")
            log_type = sess.get("log_type", "")
            if log_type == "MTK":
                port = sess.get("port", "")
                combo_values.append(f"{idx}: Port{port} Start{start_str}")
            else:
                session_id = sess.get("session_id", "")
                combo_values.append(f"{idx}: Session{session_id} Start{start_str}")
        if hasattr(self, 'progress_session_combo') and combo_values:
            self.progress_session_combo.blockSignals(True)
            self.progress_session_combo.clear()
            self.progress_session_combo.addItems(combo_values)
            self.progress_session_combo.blockSignals(False)
            self.onProgressSessionChanged()

    def onWavMatched(self, wav_files):
        logger.info(f"[AudioLog] onWavMatched: received {len(wav_files)} wav_files, keys sample: {list(wav_files.keys())[:3]}")
        self.wav_files = wav_files
        self.updateSessionsTable(self.sessions_data)

    def set_worker_data(self, worker):
        self.worker_instance = worker
        if hasattr(worker, "analyzer"):
            logger.info("AnalysisTab: analyzer loaded")
        if hasattr(worker, "wav_files"):
            self.wav_files = worker.wav_files


class AudioDump_ConverterCardsInfo(ScrollArea):
    def __init__(self, parent=None, routeKey=None):
        super().__init__(parent=parent)
        self.view = QWidget(self)
        self.routeKey = routeKey
        self.vBoxLayout = QVBoxLayout(self.view)
        self.infoCard = AppInfoCard(parent=self)
        self.descriptionCard = DescriptionCard(self)
        self.settingCard = SettingsCard(self)
        self.analysisTab = AnalysisTab(self)
        self.settingCard.set_main_window(self)
        self.setWidget(self.view)
        self.setWidgetResizable(True)
        self.setObjectName(routeKey)
        self.vBoxLayout.setSpacing(25)
        self.vBoxLayout.setContentsMargins(0, 0, 10, 30)
        self.vBoxLayout.addWidget(self.infoCard, 0, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.descriptionCard, 1, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.settingCard, 2, Qt.AlignmentFlag.AlignTop)
        self.vBoxLayout.addWidget(self.analysisTab, 3, Qt.AlignmentFlag.AlignTop)
        self.enableTransparentBackground()

    def updateSessionsTable(self, sessions_data):
        self.analysisTab.updateSessionsTable(sessions_data)

    def onWavMatched(self, wav_files):
        self.analysisTab.onWavMatched(wav_files)

    def set_worker_data(self, worker):
        self.analysisTab.set_worker_data(worker)


class AudioDump_Converterinterface:
    def __init__(self, parent=None, mainWindow=None):
        self.parent = parent
        self.mainWindow = mainWindow

    def addTab(self, routeKey, text, icon):
        logger.info("[TAB ADD] " + routeKey)
        self.mainWindow.tabBar.addTab(routeKey, text, icon)
        self.mainWindow.showInterface.addWidget(AudioDump_ConverterCardsInfo(routeKey=routeKey))
        current_widget = self.mainWindow.showInterface.findChild(AudioDump_ConverterCardsInfo, routeKey)
        if current_widget:
            self.mainWindow.showInterface.setCurrentWidget(current_widget)
            self.mainWindow.stackedWidget.setCurrentWidget(self.mainWindow.showInterface)
            self.mainWindow.tabBar.setCurrentIndex(self.mainWindow.tabBar.count() - 1)

